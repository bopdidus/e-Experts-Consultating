
export interface Country {
  name: string;
  cities:[string];
}



