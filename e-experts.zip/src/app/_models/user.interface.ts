import {IPasswordEditable} from './models.interface';

export interface User extends IPasswordEditable{
  id?: string;
  nic?: string;
  lastname?: string;
  firstname?: string;
  compay_name?: string;
  company_activity: string;
  password: string;
  email: string;
  city: string;
  phoneNumber: string;
  isCompany?:boolean;
  experience_count?: number|null;
  type: UserType;
  isActive: boolean;
  lastConnection: Date;
  photo?: string;
  country?:string;
  niu?:string;
  social_reason?:string;
  domain_activity?:string;
  trade_register?:string
}

export enum UserType {
  SUBSCRIBER = 0,
  COMPANY_SUBSCRIBER = 2,
  COMPANY_EXPERT    = 4,
  EXPERT     = 6,
 // ADMINISTRATOR = 4
}

