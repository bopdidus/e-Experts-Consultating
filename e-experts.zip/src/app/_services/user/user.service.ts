import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {TokenStorageService} from '../token-storage/token-storage.service';
import {
  ICompanyPersonalInfos,
 IPasswordEditable,
  IPersonPersonalInfos
} from '../../_models/models.interface';
import {API_BASE_URL, ROUTE_PATH_TYPES} from '../../_models/constants.interface';
import {UserType} from '../../_models/user.interface';

const rootApiPath = `${API_BASE_URL}/{type}/`;
enum UserActions {
  UPDATE_PERSONAL_INFOS, REGISTER, RESET_PWD
}

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient,
              private tokenStorageService: TokenStorageService) { }

  /**
   *
   * @param infos
   */
  savePersonalInfos(infos: IPersonPersonalInfos|ICompanyPersonalInfos): Observable<any> {
    const {data, url} = this.sanitizeData(infos);
    return this.http.put(`${url}`, infos);
  }

  /**
   *
   * @param infos
   */
  savePersonalContactInfos(infos): Observable<any> {
    const {data, url} = this.sanitizeData(infos);
    return this.http.put(`${url}`, infos);
  }

  /**
   *
   * @param infos
   */
  changePassword(infos: IPasswordEditable): Observable<any> {
    const {data, url} = this.sanitizeData(infos);
    return this.http.put(`${url}`, infos);
  }

  private sanitizeData(input): {data: any; url: string; }  {
    const data = JSON.parse(JSON.stringify(input));
    let url = '';

    //const {id, type} = this.tokenStorageService.getUser();

   // data.id = id;
   // url = rootApiPath.replace('{type}', ROUTE_PATH_TYPES[type]);

    return {data, url};
  }

}
