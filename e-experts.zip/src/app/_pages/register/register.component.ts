import { Component, OnInit, AfterContentInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import {Router} from '@angular/router';

import {TokenStorageService} from '../../_services/token-storage/token-storage.service';
import {AuthService} from '../../_services/auth/auth.service';
import {CString} from '../../_helpers/cstring.class';
import {UserRegisterVm, UserRegisterableTypes} from '../../_models/_view-models/user-register-vm.interface';
import {UserType} from '../../_models/user.interface';
import {Country} from '../../_models/country.interface';
import {TranslationService} from '../../_services/translation/translation.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit, AfterContentInit {

  form: UserRegisterVm = {} as UserRegisterVm;
  hasError = false;
  loading = false;
  errorMessage = '';
  roles = UserRegisterableTypes;
  userRoles = UserType;

  activities: any;

  countries: Country[] = [];
  towns:[string];

  formSteps: FormGroup[];

  constructor(
    private tokenStorage: TokenStorageService,
    private authService: AuthService,
    private formBuilder: FormBuilder,
    private translate: TranslationService,
    private router: Router,
    private http: HttpClient) {
    this.translate.useActive();
    this.form.type = this.roles[0].key;
  }

  ngOnInit(): void {
    this.formSteps = [
      this.formBuilder.group({
        lastname: ['', Validators.compose([Validators.required, Validators.minLength(1)])],
        firstname: ['', Validators.compose([Validators.required, Validators.minLength(1)])],
        nic: ['', Validators.compose([Validators.required, Validators.minLength(8)])],
      }),
      this.formBuilder.group({
        email: ['', Validators.compose([Validators.required, Validators.email])],
        phone_number: ['', Validators.compose([Validators.required, Validators.minLength(9)])],
      }),
      this.formBuilder.group({
        password: ['', Validators.compose([Validators.required, Validators.minLength(8)])],
        confirm_password: ['', Validators.compose([Validators.required, Validators.minLength(8)])],
      }),
    ];
    this.loadActivity();
    this.loadCountries();
  }

  ngAfterContentInit(): void {
  }

  loadActivity(){

    if(this.translate.getActiveLang() =='fr'){
      this.http.get("assets/compolsary/activities_fr.json").subscribe((data:any)=>{
        this.activities = data;
      })
    }else{
      this.http.get("assets/compolsary/activities_en.json").subscribe((data:any)=>{
        this.activities = data;
      })
    }

  }

  getSelectedCountry(){
   console.log(this.form.country);
   this.towns = this.countries.find(x=>x.name == this.form.country).cities;
  }

  loadCountries(){
      this.http.get("assets/compolsary/countries.min.json").subscribe((data:any)=>{
        data.forEach(element => {
          this.countries.push({name: element.country, cities:element.cities } );
        });

      })
  }

  submit(): void {
    switch (this.form.type) {
      case UserType.COMPANY_EXPERT:
        if (CString.isNullOrWhiteSpace(this.form.company_name) ||
          CString.isNullOrWhiteSpace(this.form.domain_activity + '') ||
          CString.isNullOrWhiteSpace(this.form.city + '')) {
          this.showError('register.requiredFields');
          return;
        }
        break;

      case UserType.EXPERT:
        if (CString.isNullOrWhiteSpace(this.form.experience_count + '')) {
          this.showError('register.requiredFields');
          return;
        }

        if (this.form.experience_count <= 0) {
          this.showError('register.invalidExperiences');
          return;
        }

      // tslint:disable-next-line:no-switch-case-fall-through
      case UserType.SUBSCRIBER:
        if (CString.isNullOrWhiteSpace(this.form.lastname) ||
          CString.isNullOrWhiteSpace(this.form.firstname) ||
          CString.isNullOrWhiteSpace(this.form.nic)) {
          this.showError('register.requiredFields');
          return;
        }
        break;

      default: this.showError('invalid');
    }

    if (CString.isNullOrWhiteSpace(this.form.password) ||
      CString.isNullOrWhiteSpace(this.form.confirm_password)) {
      this.showError('login.requiredFields');
      return;
    }

    if (!CString.IsValidPassword(this.form.password)) {
      this.showError('register.password_format');
      //return;
    }

    if (this.form.password !== this.form.confirm_password) {
      this.showError('register.passwords_missmatch');
      return;
    }

    if (!this.form.accept_conditions) {
      this.showError('register.accept_conditions_required');
      return;
    }

    this.loading = true;

    this.authService.register(this.form).subscribe(
      data => {
        this.loading = false;
        console.log(data);
        this.router.navigate(['login'], {  state: {type: this.form.type} });
      },
      err => {
        this.showError(err.message);
        console.log(err);
      }
    );
  }
/*
  uploadFile(imageInput: any){
    const file: File = imageInput.files[0];
    const reader = new FileReader();

    reader.addEventListener('load', (event: any) => {
      document.getElementById('imageBack').style.backgroundImage = "url(" + reader.result + ")";
    });
    if(file){
      reader.readAsDataURL(file);
    }
  } <button  mat-button mat-raised-button color="orange" style="position: static;" (click)="clickedButton()">
            <input #imageInput type="file" id="avatar" accept="image/*" (change)="uploadFile(imageInput)" [(ngModel)]="form.avatar" #photo="ngModel" />
            <mat-icon matPrefix class="text-orange">download</mat-icon>downlaod
          </button>

  clickedButton(){
    document.getElementById("avatar").click();
  }
*/
  showError(ressource: string): void {
    this.hasError = true;
    this.loading = false;
    this.errorMessage = ressource;
    setTimeout(() => { this.hasError = false; }, 5000);
  }


}
