import {AfterContentInit, AfterViewInit, Component, OnInit} from '@angular/core';
import * as $ from 'jquery';
import {User} from '../../../_models/user.interface';
import {TokenStorageService} from '../../../_services/token-storage/token-storage.service';
import {IExpert} from '../../../_models/models.interface';
import {TranslationService} from '../../../_services/translation/translation.service';

@Component({
  selector: 'app-expert-layout',
  templateUrl: './expert-layout.component.html',
  styleUrls: ['./expert-layout.component.css']
})
export class ExpertLayoutComponent implements OnInit, AfterViewInit {

  user: IExpert = {} as IExpert;
  hidden;

  constructor(private tokenStorageService: TokenStorageService,
              private translate: TranslationService) {
    this.translate.useActive();
  }

  ngOnInit(): void {
    this.user = this.tokenStorageService.getUser() as IExpert;
    this.hidden = "false"
  }

  ngAfterViewInit(): void {
    $('.mat-drawer-inner-container').addClass('overflow-hidden');
  }

}
