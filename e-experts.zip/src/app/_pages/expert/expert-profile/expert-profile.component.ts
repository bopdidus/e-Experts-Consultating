import { Component, OnInit } from '@angular/core';
import {TokenStorageService} from '../../../_services/token-storage/token-storage.service';
import {UserService} from '../../../_services/user/user.service';
import {IExpert} from '../../../_models/models.interface';
import {TranslationService} from '../../../_services/translation/translation.service';
import { UserType } from 'src/app/_models/user.interface';

@Component({
  selector: 'app-expert-profile',
  templateUrl: './expert-profile.component.html',
  styleUrls: ['./expert-profile.component.css']
})
export class ExpertProfileComponent implements OnInit {
  expert: IExpert = {} as IExpert;
  userRoles = UserType;

  constructor(private tokenStorageService: TokenStorageService,
              private translate: TranslationService,
              private userService: UserService) {
    this.translate.useActive();
    this.expert = this.tokenStorageService.getUser() as IExpert;

  }

  ngOnInit(): void {

  }

  /**
   *
   */
  submitPersonalInfo(): void {
    /*this.personalEdition.validate();
    if (this.personalEdition.hasError) {
      return;
    }

    this.userService.savePersonalInfos(this.personalEdition.data)
      .subscribe(
        data => {

        },
        err => {
          this.personalEdition.hasError = true;
          this.personalEdition.errorMessage = err.message;
        }
      );*/
  }

}
