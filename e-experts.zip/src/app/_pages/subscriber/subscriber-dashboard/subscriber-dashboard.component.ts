import { Component, OnInit } from '@angular/core';
import {TranslationService} from '../../../_services/translation/translation.service';

@Component({
  selector: 'app-subscriber-dashboard',
  templateUrl: './subscriber-dashboard.component.html',
  styleUrls: ['./subscriber-dashboard.component.css']
})
export class SubscriberDashboardComponent implements OnInit {

   alphabet =['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

  constructor(private translate: TranslationService) {
    this.translate.useActive();
  }

  ngOnInit(): void {
  }

}
