import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import {UserType} from '../../../_models/user.interface';
import {TokenStorageService} from '../../../_services/token-storage/token-storage.service';
import {ICompany, IPerson} from '../../../_models/models.interface';

import {UserService} from '../../../_services/user/user.service';
import {TranslationService} from '../../../_services/translation/translation.service';

@Component({
  selector: 'app-subscriber-profile',
  templateUrl: './subscriber-profile.component.html',
  styleUrls: ['./subscriber-profile.component.css']
})
export class SubscriberProfileComponent implements OnInit {
  type: UserType;
  types = UserType;

  company: ICompany = {} as ICompany;
  person: IPerson   = {} as IPerson;

  originalCompany: ICompany;
  originalPerson: IPerson;

  isInEdition = false;

  constructor(private tokenStorageService: TokenStorageService,
              private translate: TranslationService,
              private userService: UserService) {
    // Use active lang
    this.translate.useActive();

    // Get logged user from app storage
    const us = this.tokenStorageService.getUser();

    // Set current view user type
    // this.type = us.type;

    // Initialize personal infos according to the view type
    switch (this.type) {
      case UserType.COMPANY_EXPERT:

        break;

      case UserType.SUBSCRIBER:

        break;
    }
  }

  ngOnInit(): void {
    // Load data from server and apply them to view data and original view data
    this.originalCompany = JSON.parse(JSON.stringify(this.company));
    this.originalPerson = JSON.parse(JSON.stringify(this.person));
  }

  /**
   *
   */
  submitInfo(): void {

  }

  /**
   * Tells if the current user has an avatar.
   */
  hasAvatar(): boolean {
    return (this.company.avatar != null) || (this.person.avatar != null);
  }

  /**
   * Handles avatar selection changes.
   */
  onFileSelected(): void {
    if (typeof (FileReader) !== 'undefined') {
      const inputNode: any = document.querySelector('#imagePicker');
      const reader = new FileReader();

      reader.onload = (e: any) => {
          console.log(e.target.result);
          this.person.avatar = inputNode.files[0];
          this.company.avatar = inputNode.files[0];
          $('#imagePreview').css('background-image', 'url(' + e.target.result + ')');
      };

      reader.readAsDataURL(inputNode.files[0]);
    }
  }

  /**
   * Reset view data while canceling the edition.
   */
  cancelEditionClicked(): void {
    this.isInEdition = false;
    this.company = JSON.parse(JSON.stringify(this.originalCompany));
    this.person = JSON.parse(JSON.stringify(this.originalPerson));
  }
}
